/**
 * Adaptive cryptocurrency price formatting.
 * Formats prices cleanly across all scales:
 * - >= $1,000: 2 decimal places with thousands grouping (e.g., $2,732.57)
 * - >= $1: 2-4 decimal places (e.g., $4.375)
 * - >= $0.01: 4 decimal places (e.g., $0.0538)
 * - >= $0.0001: 6 decimal places (e.g., $0.000989 ➡️ $0.000999, $0.003030)
 * - < $0.0001: up to 8 decimal places (e.g., $0.00001425)
 */
export function formatCryptoPrice(price: number | null | undefined): string {
  if (price === null || price === undefined || isNaN(price)) return '—';
  const abs = Math.abs(price);
  if (abs === 0) return '0.00';
  if (abs >= 1000) {
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  if (abs >= 1) {
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  }
  if (abs >= 0.01) {
    return price.toFixed(4);
  }
  if (abs >= 0.0001) {
    return price.toFixed(6);
  }
  return price.toFixed(8);
}
