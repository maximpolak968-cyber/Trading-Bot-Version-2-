export interface BotStatus {
  isRunning: boolean;
  pid: number | null;
  uptimeSeconds: number;
  timeframe: string;
  strategy: string;
  scanAllPairs: boolean;
  stakePercent: number;
  stakeAmountConfigured: number;
  calculatedStake: number;
  maxOpenTrades: number;
  tradeablePairsCount: number;
  dryRun: boolean;
  tradingMode: string;
  totalBalanceUsdt: number;
  freeBalanceUsdt?: number;
}

export interface OrderItem {
  id: number;
  trade_id: number;
  pair: string;
  order_type: string;
  side: string;
  price: number;
  amount: number;
  cost?: number;
  fee?: number;
  realized_pnl?: number;
  action_type: string;
  status: string;
  exchange_order_id?: string;
  order_notes?: string;
  created_at: string;
}

export interface TradeItem {
  id: number;
  pair: string;
  open_rate: number;
  close_rate?: number | null;
  current_rate?: number | null;
  stake_amount: number;
  amount: number;
  is_open: boolean;
  is_short: boolean;
  open_date: string;
  close_date?: string | null;
  profit_percent?: number | null;
  profit?: number | null;
  unrealized_profit_pct?: number;
  unrealized_profit_abs?: number;
  target_tp_rate?: number | null;
  next_dca_price?: number | null;
  trade_state?: string;
  stoploss_rate?: number | null;
  dca_count?: number;
  plan_notes?: string | null;
  sell_reason?: string | null;
  timeframe: string;
  orders?: OrderItem[];
}

export interface SignalItem {
  id: string;
  pair: string;
  type: 'BUY' | 'SELL';
  direction: 'LONG' | 'SHORT';
  rate: number;
  time: string;
  stake: number;
  indicators?: {
    rsi?: number;
    ema_fast?: number;
    ema_slow?: number;
    volume_surge?: boolean;
  };
}

export interface HistoryTradeItem {
  id: number;
  pair: string;
  direction: 'LONG' | 'SHORT';
  open_rate: number;
  close_rate: number;
  amount: number;
  stake_amount: number;
  open_date: string;
  close_date: string;
  sell_reason: string;
  gross_profit: number;
  fee_total: number;
  net_profit: number;
  net_profit_percent: number;
  plan_notes?: string;
}

export interface PnLAnalytics {
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  break_even_trades: number;
  win_rate_pct: number;
  total_gross_profit: number;
  total_fees_paid: number;
  total_net_profit: number;
  profit_factor: number;
  avg_trade_net_pnl: number;
  total_volume_traded: number;
  history: HistoryTradeItem[];
}

export interface MarketMover {
  symbol: string;
  price: number;
  change_24h_pct: number;
  volume_24h_usdt: number;
  funding_rate_pct: number;
  category: 'GAINER' | 'LOSER';
}

export interface MarketMoversData {
  gainers: MarketMover[];
  losers: MarketMover[];
  all_scanned_count: number;
}

export interface EngineLog {
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SIGNAL';
  message: string;
  raw: string;
}
