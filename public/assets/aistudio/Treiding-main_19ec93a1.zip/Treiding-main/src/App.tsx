import React, { useState, useEffect, useRef } from 'react';
import { 
  BotStatus, 
  TradeItem, 
  SignalItem, 
  EngineLog, 
  PnLAnalytics, 
  MarketMoversData,
  OrderItem
} from './types';
import { formatCryptoPrice } from './utils';
import { 
  Play, 
  Square, 
  RotateCw, 
  Activity, 
  TrendingUp, 
  TrendingDown,
  Layers, 
  Percent, 
  Cpu, 
  Radio, 
  Clock, 
  ShieldCheck, 
  ExternalLink, 
  RefreshCw, 
  Search,
  CheckCircle2,
  AlertTriangle,
  Flame,
  ArrowUpRight,
  DollarSign,
  Receipt,
  Scale,
  Snowflake,
  Sparkles,
  Wallet,
  X,
  History,
  Terminal as TerminalIcon
} from 'lucide-react';

export default function App() {
  const [status, setStatus] = useState<BotStatus | null>(null);
  const [trades, setTrades] = useState<TradeItem[]>([]);
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [signals, setSignals] = useState<SignalItem[]>([]);
  const [logs, setLogs] = useState<EngineLog[]>([]);
  const [pnlAnalytics, setPnlAnalytics] = useState<PnLAnalytics | null>(null);
  const [marketMovers, setMarketMovers] = useState<MarketMoversData | null>(null);
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'ORDERS' | 'HISTORY' | 'MOVERS' | 'LOGS'>('OVERVIEW');
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'WIN' | 'LOSS'>('ALL');
  const [orderFilter, setOrderFilter] = useState<'ALL' | 'ENTRY' | 'DCA' | 'EXIT'>('ALL');
  const [selectedTradeOrders, setSelectedTradeOrders] = useState<TradeItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [logFilter, setLogFilter] = useState<'ALL' | 'SIGNAL' | 'ERROR' | 'INFO'>('ALL');
  const [autoScroll, setAutoScroll] = useState(true);

  const logContainerRef = useRef<HTMLDivElement>(null);

  const isFetchingRef = useRef(false);

  // Safe fetch helper to guarantee resilience against temporary network glitches
  const safeFetch = async <T,>(url: string, fallback: T): Promise<T> => {
    try {
      const res = await fetch(url);
      if (!res.ok) return fallback;
      return await res.json();
    } catch {
      return fallback;
    }
  };

  // Fetch all live dashboard data
  const fetchData = async () => {
    if (isFetchingRef.current) return;
    isFetchingRef.current = true;

    try {
      const [statusRes, tradesRes, signalsRes, logsRes, pnlRes, moversRes, ordersRes] = await Promise.all([
        safeFetch<BotStatus | null>('/api/status', null),
        safeFetch<TradeItem[]>('/api/trades', []),
        safeFetch<SignalItem[]>('/api/signals', []),
        safeFetch<EngineLog[]>('/api/logs', []),
        safeFetch<PnLAnalytics | null>('/api/analytics/pnl', null),
        safeFetch<MarketMoversData | null>('/api/market/movers', null),
        safeFetch<OrderItem[]>('/api/orders', [])
      ]);

      if (statusRes) setStatus(statusRes);
      setTrades(tradesRes);
      setSignals(signalsRes);
      setLogs(logsRes);
      if (pnlRes) setPnlAnalytics(pnlRes);
      if (moversRes) setMarketMovers(moversRes);
      setOrders(ordersRes);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
      isFetchingRef.current = false;
    }
  };

  useEffect(() => {
    let isMounted = true;
    let timerId: any = null;

    const poll = async () => {
      if (!isMounted) return;
      await fetchData();
      if (isMounted) {
        timerId = setTimeout(poll, 3000);
      }
    };

    poll();

    return () => {
      isMounted = false;
      if (timerId) clearTimeout(timerId);
    };
  }, []);

  // Auto scroll logs
  useEffect(() => {
    if (autoScroll && logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  // Handle bot controls (Start, Stop, Restart)
  const handleControl = async (action: 'start' | 'stop' | 'restart') => {
    setActionLoading(true);
    try {
      await fetch('/api/bot/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      await new Promise(r => setTimeout(r, 1200));
      await fetchData();
    } catch (e) {
      console.error('Control action error:', e);
    } finally {
      setActionLoading(false);
    }
  };

  const filteredLogs = logs.filter(l => {
    if (logFilter === 'ALL') return true;
    return l.level === logFilter;
  });

  const activeTrades = trades.filter(t => t.is_open);
  const closedTrades = trades.filter(t => !t.is_open);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header Bar */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-semibold tracking-tight text-white">Freqtrade Scalp Control</h1>
                <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                  Live Engine
                </span>
              </div>
              <p className="text-xs text-slate-400">1-Hour Timeframe Market Scanner & Execution Engine</p>
            </div>
          </div>

          {/* Engine Status & Control Actions */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/60 border border-slate-700/60 text-xs">
              <span className={`w-2.5 h-2.5 rounded-full ${status?.isRunning ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]' : 'bg-rose-500'}`} />
              <span className="font-medium text-slate-200">
                {status?.isRunning ? `Running (PID ${status.pid})` : 'Engine Stopped'}
              </span>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-800/40 p-1 rounded-xl border border-slate-700/50">
              {status?.isRunning ? (
                <button
                  id="btn-stop-bot"
                  onClick={() => handleControl('stop')}
                  disabled={actionLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border border-rose-500/20 transition-all disabled:opacity-50"
                  title="Stop Bot Process"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  Stop
                </button>
              ) : (
                <button
                  id="btn-start-bot"
                  onClick={() => handleControl('start')}
                  disabled={actionLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25 border border-emerald-500/30 transition-all disabled:opacity-50"
                  title="Start Bot Process"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Start
                </button>
              )}

              <button
                id="btn-restart-bot"
                onClick={() => handleControl('restart')}
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-700/50 text-slate-300 hover:bg-slate-700 border border-slate-600/40 transition-all disabled:opacity-50"
                title="Restart Bot Process"
              >
                <RotateCw className={`w-3.5 h-3.5 ${actionLoading ? 'animate-spin' : ''}`} />
                Restart
              </button>

              <button
                id="btn-refresh-data"
                onClick={fetchData}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700/40 transition-colors"
                title="Refresh Metrics"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Dashboard Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        
        {/* Core Financial & PnL Performance Cards */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
          
          {/* Card 1: Net Realized Profit (after fees) */}
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Net Profit (Чистая прибыль)</span>
              <Wallet className="w-4 h-4 text-emerald-400" />
            </div>
            <div className={`text-xl font-bold tracking-tight ${(pnlAnalytics?.total_net_profit ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {(pnlAnalytics?.total_net_profit ?? 0) >= 0 ? '+' : ''}{(pnlAnalytics?.total_net_profit ?? 0).toFixed(2)} <span className="text-xs font-normal text-slate-400">USDT</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
              <span>С вычетом всех комиссий</span>
              <span className="text-slate-300 font-mono font-medium">
                {pnlAnalytics?.total_trades ? `${pnlAnalytics.total_trades} сделок` : '0 сделок'}
              </span>
            </div>
          </div>

          {/* Card 2: Total Binance Fees Deducted */}
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Binance Fees (Уплачено комиссий)</span>
              <Receipt className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-xl font-bold text-amber-300 tracking-tight">
              -{(pnlAnalytics?.total_fees_paid ?? 0).toFixed(2)} <span className="text-xs font-normal text-slate-400">USDT</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
              <span>Фьючерс (Taker 0.05%)</span>
              <span className="text-slate-300 font-mono">Объём: ${(pnlAnalytics?.total_volume_traded ?? 0).toFixed(0)}</span>
            </div>
          </div>

          {/* Card 3: Gross Profit vs Win Rate */}
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Win Rate & Исход</span>
              <Scale className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-xl font-bold text-cyan-300 tracking-tight">
              {pnlAnalytics?.win_rate_pct ?? 0}% <span className="text-xs font-normal text-slate-400">побед</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
              <span className="text-emerald-400 font-semibold">{pnlAnalytics?.winning_trades ?? 0}W</span>
              <span className="text-slate-500">/</span>
              <span className="text-rose-400 font-semibold">{pnlAnalytics?.losing_trades ?? 0}L</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400">PF: {pnlAnalytics?.profit_factor ?? 1.0}</span>
            </div>
          </div>

          {/* Card 4: Scanner & Account Slots */}
          <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
              <span>Депозит Binance Futures</span>
              <Layers className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-xl font-bold text-white tracking-tight">
              ${(status?.totalBalanceUsdt ?? 5107.95).toFixed(2)} <span className="text-xs font-normal text-slate-400">USDT</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
              <span>Слоты: <b className="text-slate-200">{activeTrades.length} / {status?.maxOpenTrades ?? 20}</b></span>
              <span className="text-emerald-400 font-medium">Свободно: ${(status?.freeBalanceUsdt ?? 5096.36).toFixed(0)}</span>
            </div>
          </div>
        </section>

        {/* Tab Navigation Menu */}
        <section className="flex items-center gap-2 border-b border-slate-800 pb-3">
          <button
            id="tab-overview"
            onClick={() => setActiveTab('OVERVIEW')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'OVERVIEW'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity className="w-4 h-4" />
            Активные позиции & Сигналы
            {activeTrades.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-bold text-[10px]">
                {activeTrades.length}
              </span>
            )}
          </button>

          <button
            id="tab-orders"
            onClick={() => setActiveTab('ORDERS')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'ORDERS'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-400" />
            База ордеров и усреднений (SQLite)
            {orders.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono text-[10px]">
                {orders.length}
              </span>
            )}
          </button>

          <button
            id="tab-history"
            onClick={() => setActiveTab('HISTORY')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'HISTORY'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Receipt className="w-4 h-4" />
            История прибыльности и комиссий
            {pnlAnalytics?.total_trades ? (
              <span className="px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px]">
                {pnlAnalytics.total_trades}
              </span>
            ) : null}
          </button>

          <button
            id="tab-movers"
            onClick={() => setActiveTab('MOVERS')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'MOVERS'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Flame className="w-4 h-4 text-amber-400" />
            24h Movers (Gainers & Losers)
          </button>

          <button
            id="tab-logs"
            onClick={() => setActiveTab('LOGS')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'LOGS'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <TerminalIcon className="w-4 h-4" />
            Логи движка
          </button>
        </section>

        {/* TAB 1: OVERVIEW (Active Positions + Radar) */}
        {activeTab === 'OVERVIEW' && (
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Active Positions */}
            <div className="lg:col-span-2 bg-slate-900/70 border border-slate-800/80 rounded-2xl p-5 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wider">Открытые позиции</h2>
                </div>
                <span className="text-xs text-slate-400">
                  {activeTrades.length} из {status?.maxOpenTrades ?? 5} слотов занято
                </span>
              </div>

              {activeTrades.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center py-10 px-4 text-center border border-dashed border-slate-800 rounded-xl bg-slate-950/40">
                  <Search className="w-8 h-8 text-slate-600 mb-2 animate-bounce" />
                  <div className="text-sm font-medium text-slate-300">Бот активно сканирует рынок (556 фьючерсных пар)</div>
                  <p className="text-xs text-slate-500 max-w-sm mt-1">
                    Сделки открываются по мультитаймфреймовому анализу (1D тренд + 4H уровни + 1H Wave Reversal).
                  </p>
                  <div className="mt-4 flex items-center gap-2 text-xs text-slate-400 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    Лидеры роста дня (Top Gainers) и падения (Top Losers) сканируются первыми
                  </div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                        <th className="py-2.5 px-3">Пара</th>
                        <th className="py-2.5 px-3">Тип</th>
                        <th className="py-2.5 px-3">Вход ➡️ Рынок</th>
                        <th className="py-2.5 px-3">Плавающий PnL</th>
                        <th className="py-2.5 px-3">Маржа / Монет</th>
                        <th className="py-2.5 px-3">DCA Шаг</th>
                        <th className="py-2.5 px-3">Цель (TP)</th>
                        <th className="py-2.5 px-3">След. усреднение</th>
                        <th className="py-2.5 px-3">Статус защиты</th>
                        <th className="py-2.5 px-3 text-right">Ордера</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {activeTrades.map(trade => {
                        const pnlPct = trade.unrealized_profit_pct ?? 0;
                        const pnlAbs = trade.unrealized_profit_abs ?? 0;
                        const isProfit = pnlPct >= 0;
                        const ordersCount = trade.orders?.length || (trade.dca_count ? trade.dca_count + 1 : 1);
                        return (
                          <tr key={trade.id} className="hover:bg-slate-800/40 transition-colors">
                            <td className="py-3 px-3 font-semibold text-white flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                              {trade.pair}
                            </td>
                            <td className="py-3 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${trade.is_short ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                                {trade.is_short ? 'SHORT' : 'LONG'}
                              </span>
                            </td>
                            <td className="py-3 px-3 font-mono text-xs">
                              <span className="text-slate-400">${formatCryptoPrice(trade.open_rate)}</span>
                              <span className="text-slate-600 mx-1">➡️</span>
                              <span className="text-white font-semibold">${formatCryptoPrice(trade.current_rate ?? trade.open_rate)}</span>
                            </td>
                            <td className="py-3 px-3">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                                isProfit ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/20' : 'bg-rose-500/15 text-rose-300 border border-rose-500/20'
                              }`}>
                                {isProfit ? '+' : ''}{pnlPct.toFixed(2)}% ({isProfit ? '+' : ''}{pnlAbs.toFixed(2)} $)
                              </span>
                            </td>
                            <td className="py-3 px-3 font-mono text-slate-300 text-[11px]">
                              <div>{trade.stake_amount} USDT</div>
                              <div className="text-[10px] text-slate-400">{trade.amount} coins</div>
                            </td>
                            <td className="py-3 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${(trade.dca_count ?? 0) > 0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-400'}`}>
                                {(trade.dca_count ?? 0) > 0 ? `Step ${trade.dca_count} (x${Math.pow(2, trade.dca_count ?? 0)})` : 'Базовый (0)'}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-emerald-400 font-mono text-xs font-semibold">
                              {trade.target_tp_rate ? `$${formatCryptoPrice(trade.target_tp_rate)}` : '+1.2%'}
                            </td>
                            <td className="py-3 px-3 text-amber-300 font-mono text-xs">
                              {trade.next_dca_price ? `$${formatCryptoPrice(trade.next_dca_price)}` : '—'}
                            </td>
                            <td className="py-3 px-3">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-500/15 text-emerald-300 border border-emerald-500/25">
                                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                                Ждёт откат
                              </span>
                            </td>
                            <td className="py-3 px-3 text-right">
                              <button
                                onClick={() => setSelectedTradeOrders(trade)}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[11px] font-mono transition-colors"
                                title="Посмотреть историю ордеров позиции"
                              >
                                <History className="w-3 h-3 text-emerald-400" />
                                {ordersCount} {ordersCount === 1 ? 'ордер' : 'ордера'}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Live Signals Radar */}
            <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-5 flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4 text-amber-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wider">Радар сигналов 1H</h2>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  MTF Confirmed
                </span>
              </div>

              <div className="flex-1 space-y-2.5 overflow-y-auto max-h-[290px] pr-1">
                {signals.length === 0 ? (
                  <div className="text-center py-8 text-xs text-slate-500">
                    Ожидание подтвержденных сигналов 1H...
                  </div>
                ) : (
                  signals.map(sig => (
                    <div 
                      key={sig.id}
                      className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-white text-xs">{sig.pair}</span>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${sig.direction === 'LONG' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                            {sig.direction}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1">
                          Цена: <span className="font-mono text-slate-200">${formatCryptoPrice(sig.rate)}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-500 flex items-center justify-end gap-1">
                          <Clock className="w-3 h-3" />
                          {sig.time.split(' ')[1] || sig.time}
                        </div>
                        <span className="text-[10px] text-emerald-400/90 font-medium flex items-center gap-0.5 mt-0.5">
                          <ArrowUpRight className="w-3 h-3" /> Стейк 1%
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </section>
        )}

        {/* TAB: DATABASE ORDERS JOURNAL */}
        {activeTab === 'ORDERS' && (
          <section className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-5 flex flex-col space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
                    База данных ордеров (Таблица `orders` в SQLite)
                  </h2>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  История каждого фактического действия бота: первоначальные входы (INITIAL_ENTRY), шаги усреднений (DCA) и фиксации прибыли (TAKE_PROFIT). Бот помнит всё даже после перезапуска.
                </p>
              </div>

              {/* Order Filter Buttons */}
              <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                {(['ALL', 'ENTRY', 'DCA', 'EXIT'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setOrderFilter(f)}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                      orderFilter === f
                        ? 'bg-slate-800 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f === 'ALL' && `Все ордера (${orders.length})`}
                    {f === 'ENTRY' && `Входы (${orders.filter(o => o.action_type.includes('ENTRY')).length})`}
                    {f === 'DCA' && `Усреднения (${orders.filter(o => o.action_type.includes('DCA')).length})`}
                    {f === 'EXIT' && `Выходы/Тейки (${orders.filter(o => o.action_type.includes('PROFIT') || o.action_type.includes('EXIT')).length})`}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Всего ордеров в БД</span>
                <div className="text-lg font-bold text-white font-mono mt-0.5">{orders.length}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Ордеров входа</span>
                <div className="text-lg font-bold text-emerald-400 font-mono mt-0.5">
                  {orders.filter(o => o.action_type.includes('ENTRY')).length}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Ордеров усреднения (DCA)</span>
                <div className="text-lg font-bold text-amber-400 font-mono mt-0.5">
                  {orders.filter(o => o.action_type.includes('DCA')).length}
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider">Активных позиций в базе</span>
                <div className="text-lg font-bold text-sky-400 font-mono mt-0.5">{activeTrades.length}</div>
              </div>
            </div>

            {/* Orders Table */}
            {orders.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
                В базе данных пока нет записанных ордеров.
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-800/80 rounded-xl bg-slate-950/40">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px] bg-slate-900/60">
                      <th className="py-2.5 px-3">ID / Сделка</th>
                      <th className="py-2.5 px-3">Время (UTC)</th>
                      <th className="py-2.5 px-3">Пара</th>
                      <th className="py-2.5 px-3">Тип действия</th>
                      <th className="py-2.5 px-3">Сторона</th>
                      <th className="py-2.5 px-3">Цена исполнения</th>
                      <th className="py-2.5 px-3">Кол-во монет</th>
                      <th className="py-2.5 px-3">Объем (USDT)</th>
                      <th className="py-2.5 px-3">Комиссия</th>
                      <th className="py-2.5 px-3">PnL</th>
                      <th className="py-2.5 px-3 text-right">Заметки / Уровень</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    {orders
                      .filter(o => {
                        if (orderFilter === 'ENTRY') return o.action_type.includes('ENTRY');
                        if (orderFilter === 'DCA') return o.action_type.includes('DCA');
                        if (orderFilter === 'EXIT') return o.action_type.includes('PROFIT') || o.action_type.includes('EXIT');
                        return true;
                      })
                      .map(order => {
                        const isEntry = order.action_type.includes('ENTRY');
                        const isDca = order.action_type.includes('DCA');
                        const isExit = order.action_type.includes('PROFIT') || order.action_type.includes('EXIT');
                        const isBuy = order.side.toLowerCase() === 'buy';
                        const pnl = order.realized_pnl ?? 0;

                        return (
                          <tr key={order.id} className="hover:bg-slate-800/30 transition-colors">
                            <td className="py-2.5 px-3 text-slate-400">
                              #{order.id} <span className="text-slate-600">(T#{order.trade_id})</span>
                            </td>
                            <td className="py-2.5 px-3 text-slate-400 font-sans text-[11px]">
                              {order.created_at ? order.created_at.substring(0, 19) : '—'}
                            </td>
                            <td className="py-2.5 px-3 font-semibold text-white font-sans">
                              {order.pair}
                            </td>
                            <td className="py-2.5 px-3 font-sans">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                isDca ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                                isExit ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                                'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                              }`}>
                                {isDca ? `DCA Усреднение` : isExit ? `Выход / Тейк` : `Первый вход`}
                              </span>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className={`font-bold ${isBuy ? 'text-emerald-400' : 'text-rose-400'}`}>
                                {order.side.toUpperCase()}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-white font-semibold">
                              ${formatCryptoPrice(order.price)}
                            </td>
                            <td className="py-2.5 px-3 text-slate-300">
                              {order.amount}
                            </td>
                            <td className="py-2.5 px-3 text-slate-300">
                              ${(order.cost ?? (order.price * order.amount)).toFixed(2)}
                            </td>
                            <td className="py-2.5 px-3 text-slate-400 text-[10px]">
                              ${(order.fee ?? 0).toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3">
                              {pnl !== 0 ? (
                                <span className={`font-bold ${pnl > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                                  {pnl > 0 ? '+' : ''}{pnl.toFixed(2)} $
                                </span>
                              ) : (
                                <span className="text-slate-500">—</span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-right text-slate-400 font-sans text-[11px] max-w-xs truncate">
                              {order.order_notes || '—'}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        {/* TAB 2: PNL & FEE HISTORY */}
        {activeTab === 'HISTORY' && (
          <section className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-5 flex flex-col space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-emerald-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
                    История сделок и учет комиссий (PnL Accounting)
                  </h2>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Полный прозрачный расчет: Грязная прибыль/убыток - Комиссия биржи Binance (0.05% на вход и выход) = Реальный чистый заработок.
                </p>
              </div>

              {/* Filter Buttons */}
              <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                {(['ALL', 'WIN', 'LOSS'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setHistoryFilter(f)}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                      historyFilter === f
                        ? 'bg-slate-800 text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f === 'ALL' && `Все (${pnlAnalytics?.history.length ?? 0})`}
                    {f === 'WIN' && `Прибыльные (${pnlAnalytics?.winning_trades ?? 0})`}
                    {f === 'LOSS' && `Убыточные (${pnlAnalytics?.losing_trades ?? 0})`}
                  </button>
                ))}
              </div>
            </div>

            {/* Summary Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <div>
                <div className="text-xs text-slate-400">Грязный результат (Gross):</div>
                <div className={`text-base font-bold font-mono ${(pnlAnalytics?.total_gross_profit ?? 0) >= 0 ? 'text-slate-200' : 'text-slate-400'}`}>
                  {(pnlAnalytics?.total_gross_profit ?? 0) >= 0 ? '+' : ''}{(pnlAnalytics?.total_gross_profit ?? 0).toFixed(2)} USDT
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Удержано Binance (Комиссии):</div>
                <div className="text-base font-bold font-mono text-amber-400">
                  -{(pnlAnalytics?.total_fees_paid ?? 0).toFixed(2)} USDT
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Итого в карман (Net PnL):</div>
                <div className={`text-base font-bold font-mono ${(pnlAnalytics?.total_net_profit ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {(pnlAnalytics?.total_net_profit ?? 0) >= 0 ? '+' : ''}{(pnlAnalytics?.total_net_profit ?? 0).toFixed(2)} USDT
                </div>
              </div>
            </div>

            {/* Trades History Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider text-[10px]">
                    <th className="py-2.5 px-3">#</th>
                    <th className="py-2.5 px-3">Пара & Направление</th>
                    <th className="py-2.5 px-3">Дата закрытия</th>
                    <th className="py-2.5 px-3">Вход ➡️ Выход</th>
                    <th className="py-2.5 px-3">Объем позиции</th>
                    <th className="py-2.5 px-3">Грязный PnL</th>
                    <th className="py-2.5 px-3 text-amber-300">Комиссия биржи</th>
                    <th className="py-2.5 px-3 text-right">Чистый PnL (Net)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {(!pnlAnalytics?.history || pnlAnalytics.history.length === 0) ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500 italic">
                        История закрытых сделок пуста...
                      </td>
                    </tr>
                  ) : (
                    pnlAnalytics.history
                      .filter(t => {
                        if (historyFilter === 'WIN') return t.net_profit > 0;
                        if (historyFilter === 'LOSS') return t.net_profit < 0;
                        return true;
                      })
                      .map(trade => (
                        <tr key={trade.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-3 text-slate-500 text-[11px]">
                            #{trade.id}
                          </td>
                          <td className="py-3 px-3 font-sans">
                            <div className="flex items-center gap-1.5">
                              <span className="font-semibold text-white">{trade.pair}</span>
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                trade.direction === 'SHORT' ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                              }`}>
                                {trade.direction}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-500 capitalize">{trade.sell_reason.replace('_', ' ')}</div>
                          </td>
                          <td className="py-3 px-3 text-slate-400 text-[11px] font-sans">
                            {trade.close_date ? trade.close_date.replace('T', ' ').substring(0, 16) : '—'}
                          </td>
                          <td className="py-3 px-3 text-slate-300">
                            ${formatCryptoPrice(trade.open_rate)} ➡️ ${formatCryptoPrice(trade.close_rate)}
                          </td>
                          <td className="py-3 px-3 text-slate-300">
                            ${trade.stake_amount}
                          </td>
                          <td className="py-3 px-3">
                            <span className={trade.gross_profit >= 0 ? 'text-slate-200' : 'text-slate-400'}>
                              {trade.gross_profit >= 0 ? '+' : ''}{trade.gross_profit.toFixed(2)} $
                            </span>
                          </td>
                          <td className="py-3 px-3 text-amber-400">
                            -{trade.fee_total.toFixed(2)} $
                          </td>
                          <td className="py-3 px-3 text-right">
                            <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold ${
                              trade.net_profit >= 0 ? 'bg-emerald-500/15 text-emerald-300' : 'bg-rose-500/15 text-rose-300'
                            }`}>
                              {trade.net_profit >= 0 ? '+' : ''}{trade.net_profit.toFixed(2)} $ ({trade.net_profit_percent >= 0 ? '+' : ''}{trade.net_profit_percent.toFixed(2)}%)
                            </span>
                          </td>
                        </tr>
                      ))
                  )}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {/* TAB 3: 24H MOVERS (Top Gainers & Losers with Funding) */}
        {activeTab === 'MOVERS' && (
          <section className="space-y-6">
            <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
                    24h Top Movers Radar (Binance Futures)
                  </h2>
                </div>
                <span className="text-xs text-slate-400">
                  Сканируется {marketMovers?.all_scanned_count ?? 556} фьючерсных пар
                </span>
              </div>
              <p className="text-xs text-slate-400 mb-6">
                Бот непрерывно отслеживает лидеров суточного роста и падения. Для них рассчитывается статус перекупленности/перепроданности по 4H уровням и фандингу.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Top Gainers Column */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400 pb-2 border-b border-slate-800">
                    <Flame className="w-4 h-4 text-emerald-400" />
                    🔥 Лидеры роста дня (Top Gainers)
                  </div>
                  {(!marketMovers?.gainers || marketMovers.gainers.length === 0) ? (
                    <div className="py-6 text-center text-xs text-slate-500">Загрузка данных рынка...</div>
                  ) : (
                    marketMovers.gainers.map((m, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{m.symbol}</span>
                            <span className="px-2 py-0.5 rounded text-xs font-extrabold bg-emerald-500/20 text-emerald-300">
                              {m.change_24h_pct >= 0 ? '+' : ''}{m.change_24h_pct.toFixed(2)}%
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-1 font-mono">
                            Цена: ${formatCryptoPrice(m.price)} • Объём: ${(m.volume_24h_usdt / 1_000_000).toFixed(1)}M
                          </div>
                        </div>
                        <div className="text-right font-mono text-xs">
                          <div className="text-slate-400 text-[10px]">Funding Rate</div>
                          <div className={`font-semibold ${m.funding_rate_pct < 0 ? 'text-emerald-400' : 'text-slate-300'}`}>
                            {m.funding_rate_pct >= 0 ? '+' : ''}{m.funding_rate_pct.toFixed(4)}%
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Top Losers Column */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-400 pb-2 border-b border-slate-800">
                    <Snowflake className="w-4 h-4 text-rose-400" />
                    ❄️ Лидеры падения дня (Top Losers)
                  </div>
                  {(!marketMovers?.losers || marketMovers.losers.length === 0) ? (
                    <div className="py-6 text-center text-xs text-slate-500">Загрузка данных рынка...</div>
                  ) : (
                    marketMovers.losers.map((m, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{m.symbol}</span>
                            <span className="px-2 py-0.5 rounded text-xs font-extrabold bg-rose-500/20 text-rose-300">
                              {m.change_24h_pct.toFixed(2)}%
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-1 font-mono">
                            Цена: ${formatCryptoPrice(m.price)} • Объём: ${(m.volume_24h_usdt / 1_000_000).toFixed(1)}M
                          </div>
                        </div>
                        <div className="text-right font-mono text-xs">
                          <div className="text-slate-400 text-[10px]">Funding Rate</div>
                          <div className={`font-semibold ${m.funding_rate_pct < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                            {m.funding_rate_pct >= 0 ? '+' : ''}{m.funding_rate_pct.toFixed(4)}%
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

              </div>
            </div>
          </section>
        )}

        {/* TAB 4: ENGINE LOGS */}
        {activeTab === 'LOGS' && (
          <section className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <TerminalIcon className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-semibold text-white uppercase tracking-wider">Freqtrade Engine Logs</h2>
                <span className="text-xs text-slate-500 font-mono">/tmp/freqtrade.log</span>
              </div>

              {/* Log Controls & Filter */}
              <div className="flex items-center gap-2">
                <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[11px]">
                  {(['ALL', 'SIGNAL', 'INFO', 'ERROR'] as const).map(lvl => (
                    <button
                      key={lvl}
                      onClick={() => setLogFilter(lvl)}
                      className={`px-2.5 py-1 rounded-md font-medium transition-colors ${logFilter === lvl ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setAutoScroll(!autoScroll)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition-colors ${autoScroll ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-400'}`}
                >
                  Auto-scroll {autoScroll ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>

            {/* Terminal Console Box */}
            <div 
              ref={logContainerRef}
              className="w-full h-96 bg-slate-950 rounded-xl p-3.5 font-mono text-[11px] leading-relaxed overflow-y-auto border border-slate-800/80 space-y-1 selection:bg-slate-800"
            >
              {filteredLogs.length === 0 ? (
                <div className="text-slate-600 italic">No log entries matching criteria...</div>
              ) : (
                filteredLogs.map((log, idx) => {
                  let badgeClass = 'text-slate-400';
                  if (log.level === 'SIGNAL') badgeClass = 'text-emerald-400 font-semibold';
                  else if (log.level === 'ERROR') badgeClass = 'text-rose-400';
                  else if (log.level === 'WARN') badgeClass = 'text-amber-400';

                  return (
                    <div key={idx} className="flex items-start gap-2 hover:bg-slate-900/40 px-1.5 py-0.5 rounded">
                      <span className="text-slate-600 select-none shrink-0">{log.timestamp.split(' ')[1] || '00:00:00'}</span>
                      <span className={`shrink-0 uppercase px-1 rounded text-[9px] ${
                        log.level === 'SIGNAL' ? 'bg-emerald-500/20 text-emerald-300' : 
                        log.level === 'ERROR' ? 'bg-rose-500/20 text-rose-300' : 
                        log.level === 'WARN' ? 'bg-amber-500/20 text-amber-300' : 
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {log.level}
                      </span>
                      <span className={`break-all ${badgeClass}`}>
                        {log.message}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </section>
        )}

        {/* Modal: Detailed Trade Orders & Levels History */}
        {selectedTradeOrders && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white">История ордеров: {selectedTradeOrders.pair}</h3>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${selectedTradeOrders.is_short ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                        {selectedTradeOrders.is_short ? 'SHORT' : 'LONG'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 font-mono">Сделка ID #{selectedTradeOrders.id} • Статус: {selectedTradeOrders.trade_state || 'WAITING_PULLBACK'}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedTradeOrders(null)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Levels summary grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">Средний курс входа</div>
                  <div className="font-bold text-white mt-0.5">${formatCryptoPrice(selectedTradeOrders.open_rate)}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] text-emerald-400 font-sans">Целевой уровень TP</div>
                  <div className="font-bold text-emerald-300 mt-0.5">
                    {selectedTradeOrders.target_tp_rate ? `$${formatCryptoPrice(selectedTradeOrders.target_tp_rate)}` : '—'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] text-amber-400 font-sans">След. усреднение</div>
                  <div className="font-bold text-amber-300 mt-0.5">
                    {selectedTradeOrders.next_dca_price ? `$${formatCryptoPrice(selectedTradeOrders.next_dca_price)}` : '—'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] text-slate-400 font-sans">Усреднений сделано</div>
                  <div className="font-bold text-white mt-0.5">{selectedTradeOrders.dca_count ?? 0} из 5</div>
                </div>
              </div>

              {/* Orders table */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Исполненные ордера по этой сделке
                </h4>
                {(!selectedTradeOrders.orders || selectedTradeOrders.orders.length === 0) ? (
                  <div className="p-4 rounded-xl bg-slate-950 text-center text-xs text-slate-500 border border-slate-800">
                    Нет детальных ордеров для этой сделки
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60 font-mono text-xs">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase tracking-wider bg-slate-900/60">
                          <th className="p-2.5">Ордер</th>
                          <th className="p-2.5">Действие</th>
                          <th className="p-2.5">Сторона</th>
                          <th className="p-2.5">Цена</th>
                          <th className="p-2.5">Кол-во</th>
                          <th className="p-2.5">Объем $</th>
                          <th className="p-2.5">Комиссия</th>
                          <th className="p-2.5">Время</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 text-[11px]">
                        {selectedTradeOrders.orders.map(o => (
                          <tr key={o.id} className="hover:bg-slate-800/30">
                            <td className="p-2.5 text-slate-400">#{o.id}</td>
                            <td className="p-2.5 font-sans">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                o.action_type.includes('DCA') ? 'bg-amber-500/20 text-amber-300' :
                                o.action_type.includes('PROFIT') || o.action_type.includes('EXIT') ? 'bg-emerald-500/20 text-emerald-300' :
                                'bg-sky-500/20 text-sky-300'
                              }`}>
                                {o.action_type}
                              </span>
                            </td>
                            <td className="p-2.5 font-bold">
                              <span className={o.side.toLowerCase() === 'buy' ? 'text-emerald-400' : 'text-rose-400'}>
                                {o.side.toUpperCase()}
                              </span>
                            </td>
                            <td className="p-2.5 text-white">${formatCryptoPrice(o.price)}</td>
                            <td className="p-2.5 text-slate-300">{o.amount}</td>
                            <td className="p-2.5 text-slate-300">${(o.cost ?? (o.price * o.amount)).toFixed(2)}</td>
                            <td className="p-2.5 text-slate-400">${(o.fee ?? 0).toFixed(4)}</td>
                            <td className="p-2.5 text-slate-400 font-sans text-[10px]">
                              {o.created_at ? o.created_at.substring(11, 19) : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setSelectedTradeOrders(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                >
                  Закрыть
                </button>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
