#!/usr/bin/env bash
set -e

echo "=== Запуск торгового бота и веб-панели ==="

# Поддержка постоянного диска Render (/data)
if [ -d "/data" ]; then
  if [ ! -f "/data/trades.sqlite" ] && [ -f "trades.sqlite" ]; then
    echo "Копирование начальной БД на постоянный диск /data..."
    cp trades.sqlite /data/trades.sqlite
  fi
  ln -sf /data/trades.sqlite trades.sqlite
  echo "Связана база данных с постоянным диском: /data/trades.sqlite"
fi

# Запуск Python торгового движка в фоне
echo "Запуск торгового ядра Python..."
python3 -m freqtrade &
PYTHON_PID=$!
echo "Торговый бот запущен (PID: $PYTHON_PID)"

# Запуск веб-панели на порту $PORT
echo "Запуск Express веб-панели на порту ${PORT:-3000}..."
exec node dist/server.cjs
