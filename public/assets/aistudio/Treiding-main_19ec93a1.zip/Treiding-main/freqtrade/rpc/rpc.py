class RPCBase:
    pass
