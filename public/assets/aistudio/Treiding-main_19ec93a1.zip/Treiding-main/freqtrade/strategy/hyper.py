class HyperOptStrategy:
    pass
