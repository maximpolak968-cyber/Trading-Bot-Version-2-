class WebSocketManager:
    pass
