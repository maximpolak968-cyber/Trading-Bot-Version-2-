class XGBoostModel:
    pass
