class LightGBMModel:
    pass
