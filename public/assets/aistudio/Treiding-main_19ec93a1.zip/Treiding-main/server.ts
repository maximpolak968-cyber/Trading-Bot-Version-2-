import express from "express";
import path from "path";
import fs from "fs";
import { exec, execFile, spawn } from "child_process";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || "3000", 10);

  app.use(express.json());

  // Cached exchange balance helper
  let cachedBalance: { total: number; free: number } = { total: 5107.95, free: 5096.36 };
  let lastBalanceFetchTime = 0;

  const updateBalanceCache = () => {
    const now = Date.now();
    if (now - lastBalanceFetchTime < 5000) return;
    lastBalanceFetchTime = now;
    const pyCode = "import json; from freqtrade.core.config import Config; from freqtrade.exchange.exchange import ExchangeManager; cfg = Config('freqtrade/config.json'); ex = ExchangeManager(cfg.data); bal = ex.get_balance(); print(json.dumps({'total': bal.get('total', {}).get('USDT', 5107.95), 'free': bal.get('free', {}).get('USDT', 5096.36)}))";
    exec(`python3 -c "${pyCode}"`, { timeout: 6000 }, (err, stdout) => {
      try {
        const res = JSON.parse(stdout || "{}");
        if (res.total && typeof res.total === 'number') {
          cachedBalance = {
            total: Number(res.total.toFixed(2)),
            free: Number((res.free || res.total).toFixed(2))
          };
        }
      } catch (e) {}
    });
  };

  // 1. Bot status endpoint
  app.get("/api/status", async (req, res) => {
    try {
      updateBalanceCache();
      exec('ps aux | grep -i "python3 -m freqtrade" | grep -v grep', (err, stdout) => {
        let isRunning = false;
        let pid: number | null = null;
        if (stdout && stdout.trim().length > 0) {
          const parts = stdout.trim().split(/\s+/);
          if (parts.length > 1) {
            pid = parseInt(parts[1], 10);
            isRunning = true;
          }
        }

        // Read config.json
        let config: any = {};
        const configPath = path.join(process.cwd(), "freqtrade/config.json");
        if (fs.existsSync(configPath)) {
          try {
            config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
          } catch (e) {}
        }

        const stakePercent = config.stake_percent || 0.01;
        const totalDeposit = cachedBalance.total || 5107.95;
        const calculatedStake = Number((totalDeposit * stakePercent).toFixed(2));

        res.json({
          isRunning,
          pid,
          uptimeSeconds: 0,
          timeframe: config.timeframe || "1h",
          strategy: config.strategy || "ScalpingStrategy",
          scanAllPairs: config.exchange?.scan_all_pairs ?? true,
          stakePercent: stakePercent,
          stakeAmountConfigured: config.stake_amount || 50,
          calculatedStake,
          maxOpenTrades: config.max_open_trades || 20,
          tradeablePairsCount: (config.trading_mode === "futures") ? 562 : ((config.exchange?.scan_all_pairs ?? true) ? 481 : (config.exchange?.pair_whitelist?.length || 12)),
          dryRun: config.dry_run ?? false,
          tradingMode: config.trading_mode || "futures",
          totalBalanceUsdt: totalDeposit,
          freeBalanceUsdt: cachedBalance.free || totalDeposit,
        });
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // 2. Trades endpoint (Active Live Binance Positions & History with Real-Time PnL)
  app.get("/api/trades", (req, res) => {
    const pyCode = `
import sqlite3, json
from freqtrade.core.config import Config
from freqtrade.exchange.exchange import ExchangeManager

active_trades = []
closed_rows = []

try:
    conn = sqlite3.connect('trades.sqlite')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM trades WHERE is_open = 1 ORDER BY id DESC')
    db_open_rows = [dict(r) for r in cursor.fetchall()]
    db_map = {(r['pair'], bool(r.get('is_short', 0))): r for r in db_open_rows}

    # Fetch orders mapped by trade_id
    cursor.execute('SELECT * FROM orders ORDER BY id ASC')
    all_order_rows = [dict(r) for r in cursor.fetchall()]
    orders_by_trade = {}
    for o in all_order_rows:
        tid = o.get('trade_id')
        if tid not in orders_by_trade:
            orders_by_trade[tid] = []
        orders_by_trade[tid].append(o)

    cursor.execute('SELECT * FROM trades WHERE is_open = 0 ORDER BY id DESC LIMIT 50')
    closed_rows = [dict(r) for r in cursor.fetchall()]
    for r in closed_rows:
        r['is_open'] = False
        r['is_short'] = bool(r.get('is_short', 0))
        r['orders'] = orders_by_trade.get(r['id'], [])

    cfg = Config('freqtrade/config.json')
    ex = ExchangeManager(cfg.data)
    positions = ex.api.fapiPrivateV2GetPositionRisk()

    for p in positions:
        amt = float(p.get('positionAmt', 0))
        if amt != 0:
            sym = p.get('symbol', '')
            pos_side = p.get('positionSide', 'BOTH')
            is_short = (pos_side == 'SHORT') or (amt < 0)
            pair = (sym[:-4] + '/USDT') if sym.endswith('USDT') else sym
            entry_price = float(p.get('entryPrice', 0))
            mark_price = float(p.get('markPrice', 0))
            unrealized_pnl = float(p.get('unRealizedProfit', 0))
            leverage = float(p.get('leverage', 25.0))
            notional = abs(amt) * entry_price
            stake = round(notional / max(leverage, 1.0), 4)
            pnl_pct = round((unrealized_pnl / stake * 100) if stake > 0 else 0, 2)

            db_rec = db_map.get((pair, is_short)) or {}
            trade_id = db_rec.get('id', hash(f'{pair}_{pos_side}') % 100000)
            trade_item = {
                'id': trade_id,
                'pair': pair,
                'open_rate': entry_price,
                'current_rate': mark_price,
                'stake_amount': round(stake, 2),
                'amount': abs(amt),
                'is_open': True,
                'is_short': is_short,
                'leverage': leverage,
                'open_date': str(db_rec.get('open_date', 'LIVE')),
                'unrealized_profit_pct': pnl_pct,
                'unrealized_profit_abs': round(unrealized_pnl, 2),
                'target_tp_rate': db_rec.get('target_tp_rate'),
                'next_dca_price': db_rec.get('next_dca_price'),
                'trade_state': db_rec.get('trade_state', 'WAITING_PULLBACK'),
                'stoploss_rate': db_rec.get('stoploss_rate'),
                'dca_count': db_rec.get('dca_count', 0),
                'plan_notes': db_rec.get('plan_notes'),
                'timeframe': db_rec.get('timeframe', '1h'),
                'orders': orders_by_trade.get(trade_id, [])
            }
            active_trades.append(trade_item)
except Exception:
    # Fallback to local DB if exchange API is temporarily unavailable
    try:
        conn = sqlite3.connect('trades.sqlite')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM trades WHERE is_open = 1 ORDER BY id DESC')
        for r in cursor.fetchall():
            d = dict(r)
            d['is_open'] = True
            d['is_short'] = bool(d.get('is_short', 0))
            active_trades.append(d)
    except Exception:
        pass

all_trades = active_trades + closed_rows
print(json.dumps(all_trades, default=str))
`;

    execFile("python3", ["-c", pyCode], { timeout: 15000 }, (err, stdout, stderr) => {
      try {
        const trades = JSON.parse(stdout || "[]");
        res.json(trades);
      } catch (e) {
        res.json([]);
      }
    });
  });

  // 2.0 Global Orders History (Entries, DCAs, Exits)
  app.get("/api/orders", (req, res) => {
    const pyCode = `
import sqlite3, json
try:
    conn = sqlite3.connect('trades.sqlite')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM orders ORDER BY id DESC LIMIT 150')
    orders = [dict(r) for r in c.fetchall()]
    conn.close()
    print(json.dumps(orders, default=str))
except Exception as e:
    print(json.dumps([]))
`;
    execFile("python3", ["-c", pyCode], { timeout: 10000 }, (err, stdout) => {
      try {
        const orders = JSON.parse(stdout || "[]");
        res.json(orders);
      } catch (e) {
        res.json([]);
      }
    });
  });

  // 2.1 PnL & Fee Analytics (History of Profitability & Binance Fees)
  app.get("/api/analytics/pnl", (req, res) => {
    const pyCode = "import json; from freqtrade.database.database import Database; db = Database('sqlite:///trades.sqlite'); print(json.dumps(db.get_pnl_analytics(), default=str))";
    exec(`python3 -c "${pyCode}"`, (err, stdout) => {
      try {
        const stats = JSON.parse(stdout || "{}");
        res.json(stats);
      } catch (e) {
        res.json({
          total_trades: 0,
          winning_trades: 0,
          losing_trades: 0,
          win_rate_pct: 0.0,
          total_gross_profit: 0.0,
          total_fees_paid: 0.0,
          total_net_profit: 0.0,
          profit_factor: 1.0,
          history: []
        });
      }
    });
  });

  // 2.2 24h Market Movers (Top Gainers and Losers with Funding Rates)
  let cachedMovers: any = null;
  let lastMoversFetchTime = 0;
  let isMoversFetching = false;

  app.get("/api/market/movers", (req, res) => {
    const now = Date.now();
    if (cachedMovers && (now - lastMoversFetchTime < 8000)) {
      return res.json(cachedMovers);
    }

    if (isMoversFetching && cachedMovers) {
      return res.json(cachedMovers);
    }

    isMoversFetching = true;
    const pyCode = "import json; from freqtrade.core.config import Config; from freqtrade.exchange.exchange import ExchangeManager; from freqtrade.exchange.market_scanner import Market24hScanner; cfg = Config('freqtrade/config.json'); ex = ExchangeManager(cfg.data); s = Market24hScanner(ex); print(json.dumps(s.scan_market(top_n=5), default=str))";
    exec(`python3 -c "${pyCode}"`, { timeout: 10000 }, (err, stdout) => {
      isMoversFetching = false;
      try {
        const data = JSON.parse(stdout || "{}");
        if (data && (data.gainers || data.losers)) {
          cachedMovers = data;
          lastMoversFetchTime = Date.now();
        }
        res.json(cachedMovers || data);
      } catch (e) {
        res.json(cachedMovers || { gainers: [], losers: [], all_scanned_count: 0 });
      }
    });
  });

  // 3. Recent Signals parsed from engine logs
  app.get("/api/signals", (req, res) => {
    const logPath = fs.existsSync("freqtrade.log") ? "freqtrade.log" : "/tmp/freqtrade.log";
    if (!fs.existsSync(logPath)) {
      return res.json([]);
    }

    try {
      const logs = fs.readFileSync(logPath, "utf-8").split("\n");
      const signals: any[] = [];
      const seen = new Set<string>();

      // Scan reverse
      for (let i = logs.length - 1; i >= 0 && signals.length < 15; i--) {
        const line = logs[i];
        if (line.includes("Long Entry signal found") || line.includes("Short Entry signal found")) {
          const match = line.match(/(Long|Short) Entry signal found for ([A-Z0-9/]+) at ([0-9.]+)/i);
          if (match) {
            const direction = match[1].toUpperCase();
            const pair = match[2];
            const rate = parseFloat(match[3]);
            const timeStr = line.substring(0, 19);

            const key = `${pair}_${timeStr}`;
            if (!seen.has(key)) {
              seen.add(key);
              signals.push({
                id: `sig_${signals.length}_${pair}`,
                pair,
                type: direction === "LONG" ? "BUY" : "SELL",
                direction,
                rate,
                time: timeStr,
                stake: 100.0,
              });
            }
          }
        }
      }

      res.json(signals);
    } catch (e: any) {
      res.json([]);
    }
  });

  // 4. Live engine logs
  app.get("/api/logs", (req, res) => {
    const logPath = fs.existsSync("freqtrade.log") ? "freqtrade.log" : "/tmp/freqtrade.log";
    if (!fs.existsSync(logPath)) {
      return res.json([]);
    }

    try {
      const content = fs.readFileSync(logPath, "utf-8");
      const lines = content.trim().split("\n");
      const slice = lines.slice(-80); // last 80 lines

      const formatted = slice.map((raw) => {
        let level = "INFO";
        if (raw.includes("ERROR")) level = "ERROR";
        else if (raw.includes("WARNING") || raw.includes("WARN")) level = "WARN";
        else if (raw.includes("signal found") || raw.includes("Trade")) level = "SIGNAL";

        // Extract timestamp if exists
        const timestampMatch = raw.match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})/);
        const timestamp = timestampMatch ? timestampMatch[1] : "";
        const message = raw.replace(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} - [a-zA-Z0-9_-]+ - [A-Z]+ - )/, "");

        return {
          timestamp,
          level,
          message: message || raw,
          raw,
        };
      });

      res.json(formatted);
    } catch (e: any) {
      res.json([]);
    }
  });

  // 5. Bot control (Start / Stop / Restart)
  app.post("/api/bot/control", (req, res) => {
    const action = req.body?.action;

    if (action === "stop") {
      exec("pkill -f 'python3 -m freqtrade'", (err) => {
        return res.json({ success: true, message: "Bot process stopped" });
      });
    } else if (action === "start") {
      exec("pkill -f 'python3 -m freqtrade'", () => {
        exec("nohup python3 -m freqtrade > /tmp/freqtrade.log 2>&1 &", (err) => {
          return res.json({ success: !err, message: err ? err.message : "Bot started" });
        });
      });
    } else if (action === "restart") {
      exec("pkill -f 'python3 -m freqtrade'", () => {
        setTimeout(() => {
          exec("nohup python3 -m freqtrade > /tmp/freqtrade.log 2>&1 &", (err) => {
            return res.json({ success: !err, message: err ? err.message : "Bot restarted successfully" });
          });
        }, 500);
      });
    } else {
      res.status(400).json({ error: "Invalid action. Supported: start, stop, restart" });
    }
  });

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
